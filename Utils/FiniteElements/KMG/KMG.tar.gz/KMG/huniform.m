function h=huniform(p)
h=ones(size(p,1),1);
