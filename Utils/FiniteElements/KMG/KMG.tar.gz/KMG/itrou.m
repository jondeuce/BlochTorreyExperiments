function  [fd,bbox,pfix]=itrou()
fd=@dtrou;  
bbox=[-1,-1; 1,1]; pfix=[-1,-1; 1,-1; 1,1; -1,1];