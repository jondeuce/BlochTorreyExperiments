function h=hdcavity(p)
h=1+7*min(p(:,2),0).^2;