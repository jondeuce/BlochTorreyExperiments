function [fd,bbox,pfix]=itwocircle()
fd=@dtwocircle;
bbox=[-1,-1;1,1]; pfix=[]; 